from setuptools import setup,find_packages

setup(name='src1',
      version='0.0.1',
      description='it is a wine q package ',
      author='tejpal kumawat',
      packages=find_packages(),
      license='MIT')
